#include <atmel_start.h>
#include <util/delay.h>
#include <avr/sleep.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* Replace with your application code */
	while (1) {
		_delay_ms(10000);
				
		PA5_set_level(0);
		PA5_set_dir(PORT_DIR_IN);
		PA5_set_pull_mode(PORT_PULL_UP);
		PA5_set_inverted(0);
		PA5_set_isc(PORT_ISC_INPUT_DISABLE_gc);
		
		PA4_set_level(0);
		PA4_set_dir(PORT_DIR_IN);
		PA4_set_pull_mode(PORT_PULL_UP);
		PA4_set_inverted(0);
		PA4_set_isc(PORT_ISC_INPUT_DISABLE_gc);
		
		PB0_set_level(0);
		PB0_set_dir(PORT_DIR_IN);
		PB0_set_pull_mode(PORT_PULL_UP);
		PB0_set_inverted(0);
		PB0_set_isc(PORT_ISC_INPUT_DISABLE_gc);
		
		PB1_set_level(0);
		PB1_set_dir(PORT_DIR_IN);
		PB1_set_pull_mode(PORT_PULL_UP);
		PB1_set_inverted(0);
		PB1_set_isc(PORT_ISC_INPUT_DISABLE_gc);
		
		sleep_mode();
	}
}
