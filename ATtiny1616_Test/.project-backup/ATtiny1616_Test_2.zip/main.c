#include <atmel_start.h>
#include <util/delay.h>
#include <led_ctrl.h>

int main(void)
{
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	FLASH_EN_set_level(0);
	
	/* Replace with your application code */
	while (1) {
		//_delay_ms(500);
		//EN_5V_toggle_level();
	}
}
