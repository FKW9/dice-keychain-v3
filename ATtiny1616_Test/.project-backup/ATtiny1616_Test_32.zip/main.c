#include <atmel_start.h>
#include <util/delay.h>
#include <avr/sleep.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	PORTA.DIRSET = PIN5_bm;
	PORTA.OUTSET = PIN5_bm;

	/* Replace with your application code */
	while (1) {
		_delay_ms(10000);
		
		PORTA.DIRCLR = PIN5_bm;
		PORTA.OUTCLR = PIN5_bm;
		
		sleep_mode();
		
		PORTA.DIRSET = PIN5_bm;
		PORTA.OUTSET = PIN5_bm;
	}
}
