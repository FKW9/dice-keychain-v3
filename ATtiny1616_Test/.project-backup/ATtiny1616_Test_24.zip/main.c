#include <atmel_start.h>
#include <util/delay.h>
#include <led_ctrl.h>
#include <avr/sleep.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	// FLASH_EN_toggle_level();
	
	/* Replace with your application code */
	while (1) {
		_delay_ms(50);
		
		cli();
		set_single_led(0);
		sleep_cpu();
		sei();
	}
}
