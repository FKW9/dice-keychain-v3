#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		static uint32_t t = 0;
		
		if (++t > 1000)
		{
			t = 0;
			FLASH_EN_toggle_level();
		}
	}
}
